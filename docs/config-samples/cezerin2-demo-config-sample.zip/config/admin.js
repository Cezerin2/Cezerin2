// config used by dashboard client side only
module.exports = {
	// dashboard UI language
	language: 'en',
	apiBaseUrl: 'https://cezerin.net/api/v1',
	apiWebSocketUrl: 'wss://cezerin.net',
	developerMode: true
};
